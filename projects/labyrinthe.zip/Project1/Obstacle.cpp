#include "Wall.h"
#include "GameManager.h"
#include <random>
#include <ctime>
#include <iostream>

Wall::Wall(int x, int y, int w, int h)
{
	SetX(x);
	SetY(y);
	SetWidth(w);
	SetHeight(h);

	GameManager& gm = GameManager::Get();
	gm.AddObstacle(this);
}

void Wall::Update(float deltaTime)
{
}

int Wall::RandStats(int min, int max)
{
	srand(time(NULL));

	int random = (rand() % (max - min + 1)) + min;
	return random;
}




