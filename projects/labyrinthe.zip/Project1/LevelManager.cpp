#include "LevelManager.h"
#include "Wall.h"
#include "Utility.h"

LevelManager& LevelManager::Get()
{
    static LevelManager Instance;

    return Instance;
}

void LevelManager::SetNextDifficulty()
{
    if (m_difficulty == "easy")
        m_difficulty = "normal";

    else if (m_difficulty == "normal")
        m_difficulty = "hard";
}

void LevelManager::CreateLaby()
{
    Wall* dWall = new Wall(WIDTH - 20, -30, 50, HEIGHT + 30);
    Wall* aWall = new Wall(-30, -30, WIDTH + 30, 50);
    Wall* bWall = new Wall(-30, HEIGHT - 20, WIDTH + 30, 50);
    Wall* cWall = new Wall(-30, -30, 50, HEIGHT + 30);
    
    Wall* a11 = new Wall((WIDTH / 16) * 1, (HEIGHT / 12) * 2, 20, (HEIGHT / 12) * 4);
    Wall* a12 = new Wall((WIDTH / 16) * 1, (HEIGHT / 12) * 10, 20, (HEIGHT / 12) * 1);

    Wall* b11 = new Wall((WIDTH / 16) * 1, (HEIGHT / 12) * 1, (WIDTH / 16) * 1, 20);
    Wall* b12 = new Wall((WIDTH / 16) * 9, (HEIGHT / 12) * 1, (WIDTH / 16) * 1, 20);
    Wall* b13 = new Wall((WIDTH / 16) * 12, (HEIGHT / 12) * 1, (WIDTH / 16) * 3, 20);

    Wall* a21 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 1, 20, (HEIGHT / 12) * 1);
    Wall* a22 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 3, 20, (HEIGHT / 12) * 1);
    Wall* a23 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 5, 20, (HEIGHT / 12) * 1);
    Wall* a24 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 7, 20, (HEIGHT / 12) * 1);
    Wall* a25 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 9, 20, (HEIGHT / 12) * 1);
    Wall* a26 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 11, 20, (HEIGHT / 12) * 1);

    Wall* b21 = new Wall((WIDTH / 16) * 0, (HEIGHT / 12) * 2, (WIDTH / 16) * 1, 20);
    Wall* b22 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 2, (WIDTH / 16) * 2, 20);
    Wall* b23 = new Wall((WIDTH / 16) * 7, (HEIGHT / 12) * 2, (WIDTH / 16) * 7, 20);
    Wall* b24 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 2, (WIDTH / 16) * 1, 20);

    Wall* a31 = new Wall((WIDTH / 16) * 3, (HEIGHT / 12) * 0, 20, (HEIGHT / 12) * 1);
    Wall* a32 = new Wall((WIDTH / 16) * 3, (HEIGHT / 12) * 2, 20, (HEIGHT / 12) * 1);
    Wall* a33 = new Wall((WIDTH / 16) * 3, (HEIGHT / 12) * 4, 20, (HEIGHT / 12) * 5);
    Wall* a34 = new Wall((WIDTH / 16) * 3, (HEIGHT / 10) * 4, 20, (HEIGHT / 12) * 1);

    Wall* b31 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 3, (WIDTH / 16) * 1, 20);
    Wall* b32 = new Wall((WIDTH / 16) * 9, (HEIGHT / 12) * 3, (WIDTH / 16) * 1, 20);
    Wall* b33 = new Wall((WIDTH / 16) * 13, (HEIGHT / 12) * 3, (WIDTH / 16) * 2, 20);

    Wall* a41 = new Wall((WIDTH / 16) * 4, (HEIGHT / 12) * 1, 20, (HEIGHT / 12) * 1);
    Wall* a42 = new Wall((WIDTH / 16) * 4, (HEIGHT / 12) * 3, 20, (HEIGHT / 12) * 1);
    Wall* a43 = new Wall((WIDTH / 16) * 4, (HEIGHT / 12) * 7, 20, (HEIGHT / 12) * 1);
    Wall* a44 = new Wall((WIDTH / 16) * 4, (HEIGHT / 12) * 9, 20, (HEIGHT / 12) * 2);

    Wall* b40 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 4, (WIDTH / 16) * 1, 20);
    Wall* b41 = new Wall((WIDTH / 16) * 4, (HEIGHT / 12) * 4, (WIDTH / 16) * 2, 20);
    Wall* b42 = new Wall((WIDTH / 16) * 9, (HEIGHT / 12) * 4, (WIDTH / 16) * 2, 20);
    Wall* b43 = new Wall((WIDTH / 16) * 12, (HEIGHT / 12) * 4, (WIDTH / 16) * 2, 20);
    Wall* b44 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 4, (WIDTH / 16) * 1, 20);

    Wall* a51 = new Wall((WIDTH / 16) * 5, (HEIGHT / 12) * 0, 20, (HEIGHT / 12) * 3);
    Wall* a52 = new Wall((WIDTH / 16) * 5, (HEIGHT / 12) * 5, 20, (HEIGHT / 12) * 1);
    Wall* a53 = new Wall((WIDTH / 16) * 5, (HEIGHT / 12) * 8, 20, (HEIGHT / 12) * 1);

    Wall* b51 = new Wall((WIDTH / 16) * 4, (HEIGHT / 12) * 5, (WIDTH / 16) * 3, 20);
    Wall* b52 = new Wall((WIDTH / 16) * 8, (HEIGHT / 12) * 5, (WIDTH / 16) * 2, 20);
    Wall* b53 = new Wall((WIDTH / 16) * 11, (HEIGHT / 12) * 5, (WIDTH / 16) * 2, 20);
    Wall* b54 = new Wall((WIDTH / 16) * 14, (HEIGHT / 12) * 5, (WIDTH / 16) * 1, 20);

    Wall* a61 = new Wall((WIDTH / 16) * 6, (HEIGHT / 12) * 0, 20, (HEIGHT / 12) * 5);
    Wall* a62 = new Wall((WIDTH / 16) * 6, (HEIGHT / 12) * 6, 20, (HEIGHT / 12) * 1);
    Wall* a63 = new Wall((WIDTH / 16) * 6, (HEIGHT / 12) * 9, 20, (HEIGHT / 12) * 2);

    Wall* b61 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 6, (WIDTH / 16) * 3, 20);
    Wall* b62 = new Wall((WIDTH / 16) * 9, (HEIGHT / 12) * 6, (WIDTH / 16) * 3, 20);
    Wall* b63 = new Wall((WIDTH / 16) * 13, (HEIGHT / 12) * 6, (WIDTH / 16) * 2, 20);

    Wall* a71 = new Wall((WIDTH / 16) * 7, (HEIGHT / 12) * 1, 20, (HEIGHT / 12) * 3);
    Wall* a72 = new Wall((WIDTH / 16) * 7, (HEIGHT / 12) * 5, 20, (HEIGHT / 12) * 2);
    Wall* a73 = new Wall((WIDTH / 16) * 7, (HEIGHT / 12) * 8, 20, (HEIGHT / 12) * 1);
    Wall* a74 = new Wall((WIDTH / 16) * 7, (HEIGHT / 12) * 10, 20, (HEIGHT / 12) * 1);

    Wall* b71 = new Wall((WIDTH / 16) * 1, (HEIGHT / 12) * 7, (WIDTH / 16) * 1, 20);
    Wall* b72 = new Wall((WIDTH / 16) * 5, (HEIGHT / 12) * 7, (WIDTH / 16) * 3, 20);
    Wall* b73 = new Wall((WIDTH / 16) * 12, (HEIGHT / 12) * 7, (WIDTH / 16) * 3, 20);

    Wall* a81 = new Wall((WIDTH / 16) * 8, (HEIGHT / 12) * 0, 20, (HEIGHT / 12) * 1);
    Wall* a82 = new Wall((WIDTH / 16) * 8, (HEIGHT / 12) * 3, 20, (HEIGHT / 12) * 3);
    Wall* a83= new Wall((WIDTH / 16) * 8, (HEIGHT / 12) * 10, 20, (HEIGHT / 12) * 1);

    Wall* b81 = new Wall((WIDTH / 16) * 0, (HEIGHT / 12) * 8, (WIDTH / 16) * 2, 20);
    Wall* b82 = new Wall((WIDTH / 16) * 4, (HEIGHT / 12) * 8, (WIDTH / 16) * 2, 20);
    Wall* b83 = new Wall((WIDTH / 16) * 8, (HEIGHT / 12) * 8, (WIDTH / 16) * 1, 20);
    Wall* b84 = new Wall((WIDTH / 16) * 11, (HEIGHT / 12) * 8, (WIDTH / 16) * 1, 20);
    Wall* b85 = new Wall((WIDTH / 16) * 13, (HEIGHT / 12) * 8, (WIDTH / 16) * 1, 20);
    Wall* b86 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 8, (WIDTH / 16) * 1, 20);

    Wall* a91 = new Wall((WIDTH / 16) * 9, (HEIGHT / 12) * 1, 20, (HEIGHT / 12) * 1);
    Wall* a92 = new Wall((WIDTH / 16) * 9, (HEIGHT / 12) * 3, 20, (HEIGHT / 12) * 1);
    Wall* a93 = new Wall((WIDTH / 16) * 9, (HEIGHT / 12) * 7, 20, (HEIGHT / 12) * 2);
    Wall* a94 = new Wall((WIDTH / 16) * 9, (HEIGHT / 12) * 11, 20, (HEIGHT / 12) * 1);

    Wall* b91 = new Wall((WIDTH / 16) * 1, (HEIGHT / 12) * 9, (WIDTH / 16) * 3, 20);
    Wall* b92 = new Wall((WIDTH / 16) * 5, (HEIGHT / 12) * 9, (WIDTH / 16) * 8, 20);

    Wall* a101 = new Wall((WIDTH / 16) * 10, (HEIGHT / 12) * 5, 20, (HEIGHT / 12) * 3);

    Wall* b101 = new Wall((WIDTH / 16) * 0, (HEIGHT / 12) * 10, (WIDTH / 16) * 1, 20);
    Wall* b102 = new Wall((WIDTH / 16) * 2, (HEIGHT / 12) * 10, (WIDTH / 16) * 1, 20);
    Wall* b103 = new Wall((WIDTH / 16) * 4, (HEIGHT / 12) * 10, (WIDTH / 16) * 1, 20);
    Wall* b104 = new Wall((WIDTH / 16) * 7, (HEIGHT / 12) * 10, (WIDTH / 16) * 7, 20);
    Wall* b105 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 10, (WIDTH / 16) * 1, 20);

    Wall* a111 = new Wall((WIDTH / 16) * 11, (HEIGHT / 12) * 0, 20, (HEIGHT / 12) * 2);
    Wall* a112 = new Wall((WIDTH / 16) * 11, (HEIGHT / 12) * 3, 20, (HEIGHT / 12) * 2);
    Wall* a113 = new Wall((WIDTH / 16) * 11, (HEIGHT / 12) * 6, 20, (HEIGHT / 12) * 2);
    Wall* a114 = new Wall((WIDTH / 16) * 11, (HEIGHT / 12) * 11, 20, (HEIGHT / 12) * 1);

    Wall* b111 = new Wall((WIDTH / 16) * 5, (HEIGHT / 12) * 11, (WIDTH / 16) * 2, 20);
    Wall* b112 = new Wall((WIDTH / 16) * 8, (HEIGHT / 12) * 11, (WIDTH / 16) * 1, 20);
    Wall* b113 = new Wall((WIDTH / 16) * 10, (HEIGHT / 12) * 11, (WIDTH / 16) * 1, 20);
    Wall* b114 = new Wall((WIDTH / 16) * 12, (HEIGHT / 12) * 11, (WIDTH / 16) * 1, 20);

    Wall* a121 = new Wall((WIDTH / 16) * 12, (HEIGHT / 12) * 2, 20, (HEIGHT / 12) * 2);
    Wall* a122 = new Wall((WIDTH / 16) * 12, (HEIGHT / 12) * 8, 20, (HEIGHT / 12) * 1);
    Wall* a123 = new Wall((WIDTH / 16) * 12, (HEIGHT / 12) * 10, 20, (HEIGHT / 12) * 1);

    Wall* a131 = new Wall((WIDTH / 16) * 13, (HEIGHT / 12) * 5, 20, (HEIGHT / 12) * 1);
    Wall* a132 = new Wall((WIDTH / 16) * 13, (HEIGHT / 12) * 7, 20, (HEIGHT / 12) * 1);

    Wall* a141 = new Wall((WIDTH / 16) * 14, (HEIGHT / 12) * 4, 20, (HEIGHT / 12) * 1);
    Wall* a142 = new Wall((WIDTH / 16) * 14, (HEIGHT / 12) * 8, 20, (HEIGHT / 12) * 2);
    Wall* a143 = new Wall((WIDTH / 16) * 14, (HEIGHT / 12) * 11, 20, (HEIGHT / 12) * 1);

    Wall* a151 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 1, 20, (HEIGHT / 12) * 1);
    Wall* a152 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 3, 20, (HEIGHT / 12) * 1);
    Wall* a153 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 5, 20, (HEIGHT / 12) * 1);
    Wall* a154 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 8, 20, (HEIGHT / 12) * 1);
    Wall* a155 = new Wall((WIDTH / 16) * 15, (HEIGHT / 12) * 10, 20, (HEIGHT / 12) * 1);    
}
