#pragma once
#include <SDL.h>

struct SDL_Renderer;

class Menu
{
private:
	SDL_Renderer* m_renderer;
	bool MenuOpen = false;
	bool notEnough = false;
	float missingTextCD = 0.f;
	float spaceTextCD = 0.f;
	float wallTextCD = 0.f;


public:
	static Menu& Get();

	void ShowEndText();
	void ShowMissingText();
	void ShowSpaceText();
	void ShowWallText();

	void SetRenderer(SDL_Renderer* renderer) { m_renderer = renderer; }
	void SetMenu(bool isOpen) { MenuOpen = isOpen; }
	void SetMissingTextCD(float CD) { missingTextCD = CD; }
	void SetSpaceTextCD(float CD) { spaceTextCD = CD; }
	void SetWallTextCD(float CD) { wallTextCD = CD; }

	bool IsMenuOpen() { return MenuOpen; }
	float MissingTextCD() { return missingTextCD; }
	float SpaceTextCD() { return spaceTextCD; }
	float WallTextCD() { return wallTextCD; }

	void Exit();
	
};

