#pragma once
#include <fstream>

class LevelManager
{
private:
	std::streampos fsize = 0;
	std::ifstream file;

	const char* m_path = "C:/Users/cmichaut/Downloads/Jour3/Project2/level.txt";
	int m_size;
	int availableTiles;
	int totalLines = 0;

	const char* m_difficulty = "easy";

public:
	static LevelManager& Get();

	const char* GetDifficulty() {
		return m_difficulty;
	}
	void SetNextDifficulty();

	void CreateLaby();
};

