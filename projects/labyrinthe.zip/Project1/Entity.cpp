#include "Entity.h"
#include "Utility.h"
#include <SDL.h>

void Entity::Initialise(int x, int y, int width, int height)
{
	m_x = x;
	m_y = y;
	m_width = width;
	m_height = height;

	m_defaultX = x;
	m_defaultY = y;
}
void Entity::Update(float deltaTime)
{

}

void Entity::Draw(SDL_Renderer* renderer)
{
	if (m_drawable != nullptr)
		m_drawable->Draw(renderer, m_x, m_y, m_width, m_height);
}

void Entity::DrawFill(SDL_Renderer* renderer)
{
	if (m_drawable != nullptr)
		m_drawable->DrawFill(renderer, m_x, m_y, m_width, m_height);
}

bool Entity::IsCollidingCC(Entity * other) const 
{
	int dx = (m_x + m_width / 2) - (other->GetX() + other->GetWidth()/2);
	int dy = (m_y + m_height /2) - (other->GetY() + other->GetHeight()/2);
	int distanceSquared = dx * dx + dy * dy;

	int totalRadius = m_width/2 + other->GetWidth()/2;
	int radiusSquared = totalRadius * totalRadius;

	if (distanceSquared <= radiusSquared)
	{
		return true;
	}

	return false;
}

SDL_Rect* Entity::IsCollidingRR(Entity* other)
{
	SDL_Rect* A = new SDL_Rect;
	A->x = m_x;
	A->y = m_y;
	A->w = m_width;
	A->h = m_height;

	SDL_Rect* B = new SDL_Rect;
	B->x = other->m_x;
	B->y = other->m_y;
	B->w = other->m_width;
	B->h = other->m_height;

	SDL_Rect* result = new SDL_Rect;

	bool isCollide = SDL_IntersectRect(A, B, result);

	return result;
}

bool Entity::IsInLimit()
{
	if (m_x > 0 && m_x < WIDTH - m_width && m_y > 0 && m_y < HEIGHT - m_height)
		return true;

	if (m_x < 0)
		m_x = 0;
	else
		m_x = WIDTH - m_width;

	if (m_y < 0)
		m_y = 0;
	else
		m_y = HEIGHT - m_height;

	return false;
}

void Entity::Repulse(Entity* other, SDL_Rect overlap)
{
	int playerCenterX = GetX() + GetWidth() / 2;
	int playerCenterY = GetY() + GetHeight() / 2;
	int otherCenterX = other->GetX() + other->GetWidth() / 2;
	int otherCenterY = other->GetY() + other->GetHeight() / 2;

	float newX = GetX();
	float newY = GetY();

	if (overlap.w < overlap.h)
	{
		if (playerCenterX < otherCenterX)
			newX = other->GetX() - GetWidth();
		else
			newX = other->GetX() + other->GetWidth();
	}
	else
	{
		if (playerCenterY < otherCenterY)
			newY = other->GetY() - GetHeight();
		else
			newY = other->GetY() + other->GetHeight();
	}


	SetPosition(newX, newY);
}


void Entity::SetDrawable(Drawable* drawable)
{
	if (m_drawable != nullptr)
		delete m_drawable;

	m_drawable = drawable;
}

void Entity::SetPosition(float x, float y)
{
	m_x = x;
	m_y = y;
}

void Entity::SetDefaultPos()
{
	SetPosition(m_defaultX, m_defaultY);
}
