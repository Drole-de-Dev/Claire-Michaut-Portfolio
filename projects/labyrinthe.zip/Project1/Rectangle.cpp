#include "Rectangle.h"

#include <SDL.h>

void Rectangle::Draw(SDL_Renderer* renderer, int x, int y, int width, int height)
{
	SDL_RenderDrawLine(renderer, x, y, x + width, y);
	SDL_RenderDrawLine(renderer, x, y, x, y + height);
	SDL_RenderDrawLine(renderer, x + width, y, x + width, y + height);
	SDL_RenderDrawLine(renderer, x, y + height, x + width, y + height);
}

void Rectangle::DrawFill(SDL_Renderer* renderer, int x, int y, int width, int height)
{
	SDL_Rect rect = { x, y, width, height };
	SDL_RenderFillRect(renderer, &rect);
}