#include "Movable.h"
#include "GameManager.h"

Movable::Movable(int x, int y)
{
	Initialise(x, y, 10, 10);

	GameManager& gm = GameManager::Get();
	gm.AddMovable(this);
}

bool Movable::IsSafeToRepulse(SDL_Rect colideZone)
{
	


	return true;
}




