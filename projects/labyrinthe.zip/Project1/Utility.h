#pragma once
#include "stdlib.h"
#include "time.h"
#include <iostream>

#define WIDTH 1000
#define HEIGHT 700
#define XLIMIT 400

#define CENTER_X (WIDTH - 1) / 2
#define CENTER_Y (HEIGHT - 1) / 2

#define TARGET_FPS 60
#define TARGET_DELTA_TIME 1.f / TARGET_FPS

struct Vector2
{
	int x;
	int y;
};

struct Vector2f
{
	float x;
	float y;
};

struct Color
{
	int r;
	int g;
	int b;
	int a;
};

