#include "Zone.h"
#include "GameManager.h"
#include "Rectangle.h"

bool Zone::CompareColor(Color A)
{
	if (A.r == m_color.r && A.g == m_color.g && A.b == m_color.b)
		return true;
	return false;
}

void Zone::SetUpTile(int cellX, int cellY)
{
	GameManager& gm = GameManager::Get();
	gm.AddZone(this);

	float x = ((cellX - 1) * (WIDTH / 16)) + 20;
	float y = ((cellY - 1) * (HEIGHT / 12)) + 20;

	SetPosition(x, y);
	SetWidth((WIDTH / 16) - 20);
	SetHeight((HEIGHT / 12) - 20);
	SetDrawable(new Rectangle);
}
