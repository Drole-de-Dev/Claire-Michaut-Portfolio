#include "InputManager.h"
#include "Player.h"
#include "Wall.h"
#include "GameManager.h"
#include "Rectangle.h"

InputManager& InputManager::Get()
{
	static InputManager Instance;

	return Instance;
}

bool InputManager::UpdateMove(SDL_Renderer* renderer, Player* p, float deltaTime)
{

	if (IsDown(SDLK_p))
	{
		menu.SetMenu(true);
	}
	
	if (IsDown(SDLK_ESCAPE))
	{
		

		return false;
	}

	if (IsDown(SDLK_z) || IsHeld(SDLK_z))
	{
		p->Move("UP");

	}

	if (IsDown(SDLK_q) || IsHeld(SDLK_q))
	{
		p->Move("LEFT");

	}

	if (IsDown(SDLK_s) || IsHeld(SDLK_s))
	{
		p->Move("DOWN");

	}

	if (IsDown(SDLK_d) || IsHeld(SDLK_d))
	{
		p->Move("RIGHT");

	}

	if (IsDown(SDLK_SPACE))
	{
		GameManager& game = GameManager::Get();
		game.FollowSwitch();
	}
	

	return true;
}

void InputManager::HandleInput()
{
	for (int i = 0; i < SDL_NUM_SCANCODES; i++)
	{
		if (m_states[i].isDown)
			m_states[i].isHeld = true;

		if (m_states[i].isUp)
			m_states[i].isHeld = false;

		m_states[i].isDown = false;
		m_states[i].isUp = false;
	}

	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_MOUSEBUTTONDOWN:
		{
			HandleButtonEvent(event.button);
			
			break;
		}
		case SDL_MOUSEMOTION:
		{
			HandleMotion(event.motion);

			break;
		}
		case SDL_KEYDOWN:
		{
			if (event.key.repeat)
				break;

			m_states[event.key.keysym.scancode].isDown = true;
			break;
		}
		case SDL_KEYUP:
		{
			m_states[event.key.keysym.scancode].isUp = true;
			break;
		}
		}
	}
}

void InputManager::HandleButtonEvent(SDL_MouseButtonEvent& E)
{

	if (E.button == SDL_BUTTON_LEFT)
	{

		
	}
}

void InputManager::HandleMotion(SDL_MouseMotionEvent& E)
{
	GameManager& game = GameManager::Get();

	int MouseX{ E.x };
	int MouseY{ E.y };

	//std::cout << "x: " << E.x << " y: " << E.y << std::endl;

	if (!menu.IsMenuOpen())
	{
		int offsetX = game.GetEntity(0)->GetWidth() / 2;
		int offsetY = game.GetEntity(0)->GetHeight() / 2;
		game.GetEntity(0)->SetPosition(MouseX - offsetX, MouseY - offsetY); //set position of player
	}
}

bool InputManager::IsDown(SDL_KeyCode key)
{
	SDL_Scancode scancode = SDL_GetScancodeFromKey(key);

	return m_states[scancode].isDown;
}

bool InputManager::IsMousePressed(int key)
{
	SDL_Scancode scancode = SDL_GetScancodeFromKey(key);

	return m_states[scancode].isDown;
}

bool InputManager::IsHeld(SDL_KeyCode key)
{
	SDL_Scancode scancode = SDL_GetScancodeFromKey(key);

	return m_states[scancode].isHeld;
}

bool InputManager::IsUp(SDL_KeyCode key)
{
	SDL_Scancode scancode = SDL_GetScancodeFromKey(key);

	return m_states[scancode].isUp;
}