#include "Player.h"
#include "Utility.h"
#include <iostream>

Player::Player()
{
	Initialise(150, 150, 20, 20);
	SetSpeed(m_maxSpeed);
}

void Player::Update(float deltaTime)
{
	IsInLimit();
}

void Player::Move(const char* direction)
{
	

	if (direction == "UP")
	{
		SetY(GetY() - GetSpeed());
	}

	if (direction == "LEFT")
	{
		SetX(GetX() - GetSpeed());
	}

	if (direction == "DOWN")
	{
		SetY(GetY() + GetSpeed());
	}

	if (direction == "RIGHT")
	{
		SetX(GetX() + GetSpeed());
	}
}





