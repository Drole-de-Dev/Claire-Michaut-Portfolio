#include "Menu.h"
#include "Utility.h"
#include "Rectangle.h"
#include "InputManager.h"
#include "GameManager.h"
#include <SDL_ttf.h>
#include <string>

GameManager& gm = GameManager::Get();

Menu& Menu::Get()
{
	static Menu Instance;

	return Instance;
}

void Menu::ShowEndText()
{
	TTF_Font* font = TTF_OpenFont("../SDL2_ttf/Renogare-Regular.otf", 24);
	
	SDL_SetRenderDrawColor(m_renderer, 0, 0, 0, 255);
	SDL_RenderClear(m_renderer);
	MenuOpen = true;

	int w, h;
	std::string text = "You sucessfully escaped the maze, congartulation!";
	SDL_Surface* surface = TTF_RenderText_Solid(font, text.c_str(), { 150, 150, 180, 255 });
	SDL_Texture* texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_Rect dst = { (WIDTH / 2) - (text.size() * 6.5), 200, w, h};
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst);

	text = "THANKS FOR PLAYING";
	surface = TTF_RenderText_Solid(font, text.c_str(), { 250, 180, 150, 255 });
	texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_Rect dst0 = { (WIDTH / 2) - (text.size() * 8), 350, w, h };
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst0);


	SDL_DestroyTexture(texture);
	SDL_RenderPresent(m_renderer);
}

void Menu::ShowMissingText()
{
	TTF_Font* font = TTF_OpenFont("../SDL2_ttf/Renogare-Regular.otf", 24);

	int w, h;
	std::string text = "Something is missing...";
	SDL_Surface* surface = TTF_RenderText_Solid(font, text.c_str(), { 250, 50, 80, 255 });
	SDL_Texture* texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_Rect dst = { 0, 0, w, h };
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst);

	text = "Put the Red Dots on the Green Tiles before heading towards the Yellow Exit";
	surface = TTF_RenderText_Solid_Wrapped(font, text.c_str(), { 250, 180, 150, 255 }, 550);
	texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_Rect dst0 = { 0, 30, w, h };
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst0);

	TTF_SetFontOutline(font, 1);

	text = "Something is missing...";
	surface = TTF_RenderText_Solid(font, text.c_str(), { 0, 0, 0, 255 });
	texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst);

	text = "Put the Red Dots on the Green Tiles before heading towards the Yellow Exit";
	surface = TTF_RenderText_Solid_Wrapped(font, text.c_str(), { 0, 0, 0, 255 }, 550);
	texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst0);


	SDL_DestroyTexture(texture);
	SDL_RenderPresent(m_renderer);
}

void Menu::ShowSpaceText()
{
	TTF_Font* font = TTF_OpenFont("../SDL2_ttf/Renogare-Regular.otf", 30);

	int w, h;
	std::string text = "PRESS SPACE";
	SDL_Surface* surface = TTF_RenderText_Solid(font, text.c_str(), { 250, 50, 80, 255 });
	SDL_Texture* texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_Rect dst = { (WIDTH / 2) - (text.size() * 6), 0, w, h };
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst);

	text = "to detach / attach from the red dot";
	surface = TTF_RenderText_Solid(font, text.c_str(), { 250, 250, 250, 255 });
	texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_Rect dst0 = { (WIDTH / 2) - (text.size() * 7), 30, w, h};
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst0);

	TTF_SetFontOutline(font, 1);
	surface = TTF_RenderText_Solid(font, text.c_str(), { 0, 0, 0, 255 });
	texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst0);
}

void Menu::ShowWallText()
{
	TTF_Font* font = TTF_OpenFont("../SDL2_ttf/Renogare-Regular.otf", 30);

	int w, h;
	std::string text = "find the blue tile";
	SDL_Surface* surface = TTF_RenderText_Solid(font, text.c_str(), { 250, 50, 80, 255 });
	SDL_Texture* texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_Rect dst = { (WIDTH / 2) - (text.size() * 6), 0, w, h };
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst);

	text = "then press space to unlock the wall";
	surface = TTF_RenderText_Solid(font, text.c_str(), { 250, 250, 250, 255 });
	texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_Rect dst0 = { (WIDTH / 2) - (text.size() * 7), 30, w, h };
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst0);

	TTF_SetFontOutline(font, 1);
	surface = TTF_RenderText_Solid(font, text.c_str(), { 0, 0, 0, 255 });
	texture = SDL_CreateTextureFromSurface(m_renderer, surface);
	SDL_FreeSurface(surface);
	SDL_QueryTexture(texture, nullptr, nullptr, &w, &h);
	SDL_RenderCopy(m_renderer, texture, nullptr, &dst0);
}


void Menu::Exit()
{
	
}
