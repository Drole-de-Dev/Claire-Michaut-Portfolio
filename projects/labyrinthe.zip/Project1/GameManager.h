#pragma once
#include "InputManager.h"
#include "Player.h"
#include "Wall.h"
#include "Movable.h"
#include "Zone.h"

struct SDL_Renderer;
struct SDL_Texture;

class GameManager
{
private:
	bool gameLoop = true;
	bool follow = true;
	int totalOccupiedZones = 0;
	int followValue = -20;
	float CircleCorner = 26;
	int lightSize = 5000;

	SDL_Renderer* m_renderer;
	SDL_Texture* m_lightTexture;

	Player* p = new Player;
	std::vector<Entity*> m_Entities;
	std::vector<Wall*> m_Walls;
	std::vector<Movable*> m_Movables;
	std::vector<Zone*> m_Zones;

	InputManager& im = InputManager::Get();
public:
	static GameManager& Get();

	void Start(SDL_Renderer* renderer);
	void Drawing();
	void RenderLight();
	float FPS(int start);
	void InitDifficulty(const char* difficulty);

	void DestroyObstacle(int index);
	void DestroyEverything();
	void End();

	void SetGameLoop(bool playLoop) { gameLoop = playLoop; }

	void FollowSwitch();
	Entity* GetEntity(int index) { return m_Entities[index]; }
	std::vector<Wall*> GetObstacles() { return m_Walls; }
	std::vector<Movable*> GetMovables() { return m_Movables; }
	std::vector<Zone*> GetZones() { return m_Zones; }

	void AddObstacle(Wall* o);
	void AddMovable(Movable* o);
	void AddZone(Zone* o);
};

