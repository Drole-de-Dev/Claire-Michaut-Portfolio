#pragma once
#include "Entity.h"

class Wall : public Entity
{
private:
	bool tempWall = false;

public:
	Wall(int x, int y, int w, int h);

	void Update(float deltaTime) override;

	int RandStats(int min, int max);
	bool GetTempWall() { return tempWall; }
	void SetTempWall(bool isTemp) {tempWall = isTemp; }
};

