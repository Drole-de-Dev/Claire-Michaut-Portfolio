#include "GameManager.h"
#include "LevelManager.h"
#include "Rectangle.h"
#include "Utility.h"
#include "Menu.h"
#include <SDL.h>
#include <SDL_ttf.h>
#include <string>

GameManager& GameManager::Get()
{
	static GameManager Instance;

	return Instance;
}

void GameManager::Start(SDL_Renderer* renderer)
{
	//INIT
	Menu& menu = Menu::Get();
	LevelManager& lg = LevelManager::Get();
	menu.SetRenderer(renderer);
	srand(time(NULL));
	m_renderer = renderer;
	float deltaTime = 1.f;

	m_Entities.push_back(p);
	m_Entities[0]->SetDrawable(new Rectangle);

	InitDifficulty("easy");

	m_lightTexture = SDL_CreateTexture(m_renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, WIDTH, HEIGHT);
	SDL_SetTextureBlendMode(m_lightTexture, SDL_BLENDMODE_BLEND);


	Color orange = { 220, 170, 70, 255 };
	Color blue = { 10, 20, 250, 255 };
	Color green = { 170, 220, 70, 255 };

	SDL_Rect r({ 0, 0, 0, 0 });

	//LOOP
	while (gameLoop)
	{
		Uint64 firstFrame = SDL_GetTicks64();

		//EVENT
		im.HandleInput();


		//UPDATE
		if (!im.UpdateMove(renderer, p, deltaTime)) // pressed escape
			gameLoop = false;

		m_Entities[0]->Update(deltaTime);

		if (p->IsCollidingRR(m_Walls[m_Walls.size() - 1])->w > 0 && p->IsCollidingRR(m_Walls[m_Walls.size() - 1])->h > 0 && lg.GetDifficulty() != "easy") //player collide with temp wall
			menu.SetWallTextCD(3);

		for (int i = 1; i < m_Zones.size(); i++)
		{
			if (p->IsCollidingRR(m_Zones[i])->w > 0 && p->IsCollidingRR(m_Zones[i])->h > 0  && m_Zones[i]->CompareColor(green)) // player on green tile
			{
				if (follow)
					menu.SetSpaceTextCD(0.1);
			}

			if (p->IsCollidingRR(m_Zones[i])->w > 0 && p->IsCollidingRR(m_Zones[i])->h > 0 && im.IsDown(SDLK_SPACE) && m_Zones[i]->CompareColor(blue)) // player on blue tile
			{
				m_Zones[i]->SetColor({ 50,50,50,255 });
				m_Walls[m_Walls.size() -1]->SetWidth(0);
			}

			
		}

		if (p->IsCollidingRR(m_Zones[0])->w > 0 && p->IsCollidingRR(m_Zones[0])->h > 0)//player on winTile
		{
			for (int i = 1; i < m_Zones.size(); i++)
			{
				if (!m_Zones[i]->CompareColor(green))// only check for greenTiles
					continue;

				for (int j = 0; j < m_Movables.size(); j++)
				{
					if (m_Movables[j]->IsCollidingRR(m_Zones[i])->w > 0 && m_Movables[j]->IsCollidingRR(m_Zones[i])->h > 0 && m_Zones[i]->GetOccupied() == false)//red on green
					{
						m_Zones[i]->SetOccupied(true);
						totalOccupiedZones++;
					}
				}
			}

			if (totalOccupiedZones == 2) // every GreenTiles occupied by movables
			{
				if (lg.GetDifficulty() != "hard")
				{
					p->SetPosition(150, 150);
					lg.SetNextDifficulty();
					InitDifficulty(lg.GetDifficulty());
				}
				else
					gameLoop = false;
			}
			else
				menu.SetMissingTextCD(8);
		}

		
		for (int i = 0; i < m_Walls.size(); i++)
		{
			m_Walls[i]->Update(deltaTime);

			SDL_Rect colideZone = *p->IsCollidingRR(m_Walls[i]);
			if (colideZone.w > 0 && colideZone.h > 0)
				p->Repulse(m_Walls[i], colideZone);


			for (int j = 0; j < m_Movables.size(); j++)
			{
				SDL_Rect colideZone = *m_Movables[j]->IsCollidingRR(p);
				if (colideZone.w > followValue && colideZone.h > followValue)
					m_Movables[j]->Repulse(p, colideZone);

				SDL_Rect colideZones = *m_Movables[j]->IsCollidingRR(m_Walls[i]);
				if (colideZones.w > 0 && colideZones.h > 0)
					m_Movables[j]->Repulse(m_Walls[i], colideZones);

				if (!m_Movables[j]->IsInLimit())
					m_Movables[j]->SetDefaultPos();
			}
		}


		if (menu.MissingTextCD() > 0)
			menu.SetMissingTextCD(menu.MissingTextCD() - deltaTime);
		if (menu.SpaceTextCD() > 0)
			menu.SetSpaceTextCD(menu.SpaceTextCD() - deltaTime);
		if (menu.WallTextCD() > 0)
			menu.SetWallTextCD(menu.WallTextCD() - deltaTime);

		//DRAW
		Drawing();

		//FPS
		deltaTime = FPS(firstFrame);
		
		//gameLoop = false;
	}
}

void GameManager::Drawing()
{
	Menu& menu = Menu::Get();
	SDL_SetRenderDrawColor(m_renderer, 0, 0, 0, 255);
	SDL_RenderClear(m_renderer);

	for (int i = 0; i < m_Zones.size(); i++)
	{
		SDL_SetRenderDrawColor(m_renderer, m_Zones[i]->GetColor().r, m_Zones[i]->GetColor().g, m_Zones[i]->GetColor().b, 255);
		m_Zones[i]->DrawFill(m_renderer);
	}

	SDL_SetRenderDrawColor(m_renderer, 1900, 120, 230, 255); //player color  250, 100, 204
	m_Entities[0]->DrawFill(m_renderer);

	for (int i = 0; i < m_Walls.size(); i++)
	{
		if (m_Walls[i]->GetTempWall())
			SDL_SetRenderDrawColor(m_renderer, 250, 255, 234, 255); //temporary wall color
		else
			SDL_SetRenderDrawColor(m_renderer, 0, 255, 234, 255); //permanent wall color
		m_Walls[i]->DrawFill(m_renderer);
	}

	SDL_SetRenderDrawColor(m_renderer, 205, 70, 35, 255); //movable color
	for (int i = 0; i < m_Movables.size(); i++)
		m_Movables[i]->DrawFill(m_renderer);

	RenderLight();

	//Text in game
	if (menu.MissingTextCD() > 0)
		menu.ShowMissingText();

	if (menu.SpaceTextCD() > 0)
		menu.ShowSpaceText();

	if (menu.WallTextCD() > 0)
		menu.ShowWallText();

	SDL_RenderPresent(m_renderer);
}

void GameManager::RenderLight()
{
	SDL_SetRenderDrawBlendMode(m_renderer, SDL_BLENDMODE_NONE);
	SDL_SetRenderTarget(m_renderer, m_lightTexture);
	SDL_SetRenderDrawColor(m_renderer, 0, 0, 0, 255);
	SDL_RenderClear(m_renderer);

	std::vector<SDL_Vertex> vertices;

	vertices.push_back({ {p->GetX() + (p->GetWidth() / 2), p->GetY() + (p->GetHeight()/2)}, {255, 255, 255, 0}, {0, 0}});

	for (float i = 0; i < 360.f; i += 360.f / CircleCorner ) {

		float x = p->GetX() + (p->GetWidth() / 2) + lightSize * cos(i * M_PI / 180);
		float y = p->GetY() + (p->GetHeight() / 2) + lightSize * sin(i * M_PI / 180);
		vertices.push_back({ { x, y }, {0, 0, 0, 255}, {0, 0} });
	}

	std::vector<int> indices;

	for (float i = 1; i < CircleCorner; i++) {
		indices.push_back(0);
		indices.push_back(i);
		indices.push_back(i + 1);
	}

	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(vertices.size() - 1);

	SDL_RenderGeometry(m_renderer, nullptr, vertices.data(), vertices.size(), indices.data(), indices.size());

	SDL_FRect rect = { 0, 0, WIDTH, HEIGHT };
	SDL_SetRenderTarget(m_renderer, nullptr);
	SDL_RenderCopyF(m_renderer, m_lightTexture, nullptr, &rect);
}

float GameManager::FPS(int start)
{
	Uint64 end = SDL_GetTicks64();

	float deltaTime = (end - start) / 1000.f;
	float diff = TARGET_DELTA_TIME - deltaTime;

	if (diff > 0)
	{
		SDL_Delay(diff * 1000);
		deltaTime = TARGET_DELTA_TIME;
	}

	return deltaTime;
}

void GameManager::DestroyObstacle(int index)
{
	delete(m_Walls[index]);
	m_Walls.erase(m_Walls.begin() + index);
	m_Entities.erase(m_Entities.begin() + index + 1);
}

void GameManager::DestroyEverything()
{
	while (m_Walls.size() > 0)
		DestroyObstacle(0);
	for (int i = 0; i < m_Zones.size(); i)
	{
		delete(m_Zones[0]);
		m_Zones.erase(m_Zones.begin());
	}
	for (int i = 0; i < m_Movables.size(); i)
	{
		delete(m_Movables[0]);
		m_Movables.erase(m_Movables.begin());
	}
	for (int i = 1; i < m_Entities.size(); i) //delete every entity except player at index 0
	{
		m_Entities.erase(m_Entities.begin() + 1);
	}
}


void GameManager::End()
{
	Menu& m = Menu::Get();
	m.ShowEndText();
}

void GameManager::FollowSwitch()
{
	if (follow)
	{
		follow = false;
		followValue = 0;
	}
	else
	{
		follow = true;
		followValue = -10;
	}
}

void GameManager::AddObstacle(Wall* o)
{
	o->SetDrawable(new Rectangle);
	m_Entities.push_back(o);
	m_Walls.push_back(o);
}

void GameManager::AddMovable(Movable* o)
{
	o->SetDrawable(new Rectangle);
	m_Entities.push_back(o);
	m_Movables.push_back(o);
}

void GameManager::AddZone(Zone* o)
{
	o->SetDrawable(new Rectangle);
	m_Entities.push_back(o);
	m_Zones.push_back(o);
}

void GameManager::InitDifficulty(const char* difficulty)
{
	LevelManager& lg = LevelManager::Get();
	DestroyEverything();
	lg.CreateLaby();

	totalOccupiedZones = 0;
	Color orange = { 220, 170, 70, 255 };
	Color blue = { 10, 20, 250, 255 };
	Color green = { 170, 220, 70, 255 };

	Zone* winTile = new Zone;//		Orange
	winTile->SetUpTile(9, 11);
	winTile->SetColor(orange);

	Zone* greenTileA = new Zone;//	Green
	greenTileA->SetUpTile(3, 5);
	greenTileA->SetColor(green);
	Zone* greenTileB = new Zone;
	greenTileB->SetUpTile(8, 4);
	greenTileB->SetColor(green);

	Movable* moveDotA = new Movable(80, 60);//	Red
	Movable* moveDotB = new Movable(800, 600);

	if (difficulty == "normal")
	{
		Zone* blueTile = new Zone;//	Dark Blue
		blueTile->SetUpTile(16, 2);
		blueTile->SetColor(blue);

		Wall* tempWall = new Wall(WIDTH - 130, HEIGHT - 198, (WIDTH / 16), 20);
		tempWall->SetTempWall(true);
	}

	else if (difficulty == "hard")
	{
		Zone* blueTile = new Zone;//	Dark Blue
		blueTile->SetUpTile(16, 2);
		blueTile->SetColor(blue);

		Wall* tempWall = new Wall(WIDTH - 130, HEIGHT - 198, (WIDTH / 16), 20);
		tempWall->SetTempWall(true);

		lightSize = 50;
	}
	
}
