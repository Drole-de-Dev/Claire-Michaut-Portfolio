#pragma once
#include "Entity.h"
#include "Utility.h"

class Zone : public Entity
{
private:
	bool isOccupied = false;
	Color m_color = { 0,0,0,0 };

public:
	Zone() {}

	bool CompareColor(Color A);

	void SetUpTile(int cellX, int cellY);
	void SetColor(Color c) { m_color = c; }
	void SetOccupied(bool boolean) { isOccupied = boolean; }

	Color GetColor() { return m_color; }
	bool GetOccupied() { return isOccupied; }


};

