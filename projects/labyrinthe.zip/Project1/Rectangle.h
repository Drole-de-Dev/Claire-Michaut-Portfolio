#pragma once

#include "Drawable.h"

class Rectangle : public Drawable
{
private:

public:

	Rectangle() {};

	void Draw(SDL_Renderer* renderer,  int x, int y, int width, int height) override;
	void DrawFill(SDL_Renderer* renderer, int x, int y, int width, int height) override;
};
