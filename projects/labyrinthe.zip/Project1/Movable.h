#pragma once
#include "Entity.h"

class Movable : public Entity
{
private:

public:
	Movable(int x, int y);

	bool IsSafeToRepulse(SDL_Rect colideZone);
};

