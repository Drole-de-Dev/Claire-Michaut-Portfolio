#include <iostream>
#include <SDL_ttf.h>
#include "GameManager.h"

int main(int argc, char* argv[])
{
	if (SDL_Init(SDL_INIT_VIDEO) != 0)
	{
		std::cout << "SDL_Init Error: " << SDL_GetError() << std::endl;
		return 1;
	}

	SDL_Window* window = SDL_CreateWindow("Labyrinth", CENTER_X, 100, WIDTH, HEIGHT, SDL_WINDOW_SHOWN);
	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	if (!window)
	{
		std::cout << "SDL_CreateWindow Error: " << SDL_GetError() << std::endl;
		SDL_Quit();
		return 1;
	}

	TTF_Init();
	std::cout << "Controls: ZQSD\nInteract: SPACE\nDebug move: mouse\n\n			GOAL\n" <<
		"Get to the orange tile at the bottom of the labyrinth 3 times to leave.\nHowever, you need to first unlock the exit " <<
		"by putting the red dots on the green tiles.\nThe level difficulty increases each time you try to leave.\nIn normal difficulty, " <<
		"a wall will appear. You will need to interact with a switch tile to get rid of it.\nIn hard difficulty, something special might happen, good luck!" << std::endl;

	GameManager& game = GameManager::Get();
	game.Start(renderer);

	std::cout << "game closing in 10 seconds..." << std::endl;
	game.End();

	SDL_Delay(10000);
	SDL_DestroyWindow(window);
	SDL_Quit();

	return 0;
}