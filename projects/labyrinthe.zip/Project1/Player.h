#pragma once
#include "Entity.h"

class Color;

class Player : public Entity
{
private:
	float m_maxSpeed = 7.f;

public:
	Player();

	void Update(float deltaTime) override;

	void Move(const char* direction);
};