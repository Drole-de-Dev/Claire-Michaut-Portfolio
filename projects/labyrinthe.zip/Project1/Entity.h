#pragma once
#include "Drawable.h"
#include "Utility.h"
#include <vector>

class SDL_Rect;

class Entity
{
private:
	float m_x = 0;
	float m_y = 0;
	int m_width = 0;
	int m_height = 0;
	float m_speed = 500;
	int m_defaultX;
	int m_defaultY;

	float randDelay = 0.5f;
	int randHeight = 0;
	bool reload = false;

	Drawable* m_drawable = nullptr;

public:
	void Initialise(int x, int y, int width, int height);

	virtual void Update(float deltaTime);
	void Move() {};
	void Draw(SDL_Renderer* renderer);
	void DrawFill(SDL_Renderer* renderer);

	bool IsCollidingCC(Entity* other) const;
	SDL_Rect* IsCollidingRR(Entity* other);
	bool IsInLimit();
	void Repulse(Entity* other, SDL_Rect overlap);

	float GetWidth() { return m_width; }
	float GetHeight() { return m_height; }
	float GetX() { return m_x; }
	float GetY() { return m_y; }
	float GetSpeed() { return m_speed; }
	float GetRandDelay() { return randDelay; }
	int GetRandHeight() { return randHeight; }
	bool GetReload() { return reload; }

	void SetDrawable(Drawable* drawable);
	virtual void SetPosition(float x, float y);
	void SetDefaultPos();
	void SetWidth(float value) { m_width = value; }
	void SetHeight(float value) { m_height = value; }
	void SetX(int value) { m_x = value; }
	void SetY(int value) { m_y = value; }
	void SetSpeed(float value) { m_speed = value; }
	void SetRandDelay(float value) {randDelay = value; }
	void SetRandHeight(int value) {randHeight = value; }
	void SetReload(bool b) {reload = b; }
};

