#pragma once
#include "Menu.h"
#include "SDL.h"
#include <iostream>
#include <map>

class Player;

class InputManager
{
private:

	struct State
	{
		bool isDown;
		bool isHeld;
		bool isUp;
	};

	State m_states[SDL_NUM_SCANCODES];
	Menu& menu = Menu::Get();

public:
	static InputManager& Get();

	bool UpdateMove(SDL_Renderer* renderer, Player* p, float deltaTime);
	void HandleInput();
	void HandleButtonEvent(SDL_MouseButtonEvent& E);
	void HandleMotion(SDL_MouseMotionEvent& E);

	bool IsMousePressed(int key);
	bool IsDown(SDL_KeyCode key);
	bool IsHeld(SDL_KeyCode key);
	bool IsUp(SDL_KeyCode key);
};

