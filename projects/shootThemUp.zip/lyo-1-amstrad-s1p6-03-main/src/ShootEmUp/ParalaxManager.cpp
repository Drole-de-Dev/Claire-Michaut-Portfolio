#include "ParalaxManager.h"

ParalaxManager& ParalaxManager::Get()
{
	static ParalaxManager Instance;

	return Instance;
}

Image* ParalaxManager::CreateParalax(SDL_Renderer* renderer, Entity* entity, int x, int y, int width, int height)
{
	EntityManager& em = EntityManager::Get();
	Image* p = new Image;
	m_Paralax.push_back(p);
	currentPath = NewPath();
	p->InitImage(renderer, p, GetCurrentPath(), x, y, width, height);
	entity->SetDrawable(p);

	em.AddEntities(entity);
	return p;
}

void ParalaxManager::ParaList()
{
	m_paths.push_back("../../res/Sprites/Background/Planet1.png");
	m_paths.push_back("../../res/Sprites/Background/Planet2.png");
	m_paths.push_back("../../res/Sprites/Background/Planet3.png");
	m_paths.push_back("../../res/Sprites/Background/Planet4.png");
	m_paths.push_back("../../res/Sprites/Background/Planet5.png");
	m_paths.push_back("../../res/Sprites/Background/Planet6.png");
	m_paths.push_back("../../res/Sprites/Background/Planet7.png");
	m_paths.push_back("../../res/Sprites/Background/Planet8.png");
	m_paths.push_back("../../res/Sprites/Background/Planet9.png");
}

const char* ParalaxManager::NewPath()
{
	srand(time(NULL));
	int random = rand() % 9;

	currentPath = m_paths[random];

	return currentPath;
}
