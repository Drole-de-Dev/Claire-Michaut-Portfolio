#include <iostream>
#include "EntityManager.h"
#include "EnemyManager.h"
#include "LevelManager.h"
#include "VerticalEnemy.h"
#include "ObstacleEnemy.h"
#include "Boss.h"
#include "Projectile.h"
#include "Image.h"
#include "Circle.h"



EnemyManager& EnemyManager::Get()
{
	static EnemyManager Instance;

	return Instance;
}

void EnemyManager::SpawnWave(SDL_Renderer* renderer)
{
	LevelManager& lm = LevelManager::Get();
	EntityManager& em = EntityManager::Get();
	Enemy* enemy;
	Image* image;

	for (int i = 0; i < lm.GetString().size(); i++)
	{
		std::string currLine = lm.GetString()[i];

		switch (currLine[currentWave])
		{
		case '0':
			enemy = new ObstacleEnemy();
			image = new Image();
			enemy->Initialise(0, 0, 75, 75);
			enemy->SetDrawable(image);
			image->InitImage(renderer, image, "../../res/Sprites/Enemies/meteor.png", enemy->GetX(), enemy->GetY(), enemy->GetWidth(), enemy->GetHeight());
			enemy->SetPosition(600, 100 + (160 * i), 0.5, 0.5);
			AddEnemy(enemy);
			em.ChangeEnemyNbr(1);
			break;

		case '1':
			enemy = new VerticalEnemy();
			image = new Image();
			enemy->Initialise(0, 0, 75, 75);
			enemy->SetDrawable(image);
			image->InitImage(renderer, image, "../../res/Sprites/Enemies/VerticalDemon.png", enemy->GetX(), enemy->GetY(), enemy->GetWidth(), enemy->GetHeight());
			enemy->SetPosition(600, 100 + (160 * i), 0.5, 0.5);
			AddEnemy(enemy);
			em.ChangeEnemyNbr(1);
			break;

		case '2':
			enemy = new Boss();
			image = new Image();
			enemy->Initialise(0, 0, 128, 128);
			enemy->SetDrawable(image);
			image->InitImage(renderer, image, "../../res/Sprites/Boss/Flandre.png", enemy->GetX(), enemy->GetY(), enemy->GetWidth(), enemy->GetHeight());
			enemy->SetPosition(600, HEIGHT / 2, 0.5, 0.5);
			AddEnemy(enemy);
			em.ChangeEnemyNbr(1);
			break;
		}
	}
}

void EnemyManager::NextWave()
{
	currentWave++;
}

void EnemyManager::AddEnemy(Enemy* enemy)
{
	m_EnemyOnScreen.push_back(enemy);
}

void EnemyManager::DeleteEnemy(int i)
{
	m_EnemyOnScreen.erase(m_EnemyOnScreen.begin() + i);
}
