#pragma once

#include "Drawable.h"

#define DEFAULT_PRECISION 40

class Circle : public Drawable
{
private:
	int m_precision;

public:
	Circle(int precision = DEFAULT_PRECISION);

	void Draw(SDL_Renderer* renderer, int x, int y, int width, int height) override;

	//int GetRadius() const { return m_width / 2; }

	//bool IsColliding(const Circle* target);
};
