#pragma once

#include "Entity.h"

class Character : public Entity
{
protected:
	int m_attack = 0;
	int m_health = 0;
	float m_speed = 0;

public:
	Character() {};

	void TakeDamage(int dmg);

	void Update(SDL_Renderer* renderer, float deltaTime);

	bool IsAlive();
};