#include "GameManager.h"
#include "LevelManager.h"
#include "EnemyManager.h"
#include <iostream>
#include <fstream>
#include <string>

LevelManager& LevelManager::Get()
{
	static LevelManager Instance;

	return Instance;
}

bool LevelManager::HandleLevel(SDL_Renderer* renderer)
{
	GameManager& gm = GameManager::Get();
	EnemyManager& enM = EnemyManager::Get();

	if (enM.GetEnemyList().size() == 0)
	{
		if (GetString().size() == 0)
			LoadLevel("../../res/Level/lvl1.txt");

		if (enM.GetWave() == GetString().size() - 1)
			return false;

		enM.SpawnWave(renderer);
		enM.NextWave();
	}

	return true;
}

void LevelManager::LoadLevel(const char* path)
{
	std::ifstream file(path);

	if (file.is_open() == false)
		return; //error

	std::string line;
	while (std::getline(file, line)) 
	{
		level.push_back(line);
	}
	file.close();
}
