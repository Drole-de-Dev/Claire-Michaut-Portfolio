#include "EntityManager.h"
#include "Projectile.h"
#include "Image.h"

#include <SDL.h>

Projectile::Projectile(int width, int height, int speed, int xDir, int yDir) : Entity()
{
	m_width = width;
	m_height = height;
	m_speed = speed;
	m_direction.x = xDir;
	m_direction.y = yDir;
}

void Projectile::Explosion(SDL_Renderer* renderer, float deltaTime)
{
	EntityManager& em = EntityManager::Get();

	Image* image;

	for (int i = -1; i <= 1; i++)
	{
		for (int j = -1; j <= 1; j++)
		{
			if (i == 0 && j == 0)
				continue;
			image = new Image();
			Projectile* attack = new Projectile(20, 20, 175, i, j);
			image->InitImage(renderer, image, "../../res/Sprites/Boss/LittleCrystal.png", GetX(), GetY(), attack->GetWidth(), attack->GetHeight());
			attack->SetDrawable(image);
			attack->SetPosition(GetPosition(0.f, 0.5f).x - 10, GetPosition(0.5f, 0.5f).y, 0.f, 0.5f);
			em.AddEnemyProj(attack);
		}
	}
}

void Projectile::SetExplosionZone()
{
	m_explosionZone = (rand() % 200) + 101;
}
