#include <iostream>

#include "GameManager.h"
#include "EntityManager.h"
#include "EnemyManager.h"
#include "Entity.h"
#include "Hero.h"
#include "Enemy.h"
#include "VerticalEnemy.h"
#include "Projectile.h"
#include "Image.h"


EntityManager& EntityManager::Get()
{
	static EntityManager Instance;

	return Instance;
}

Image* EntityManager::CreateEntity(SDL_Renderer* renderer, Entity* entity, int x, int y, float ax, float ay, int width, int height, const char* path)
{
	Image* image = new Image();
	entity->Initialise(x, y, width, height);
	entity->SetPosition(x, y, ax, ay);
	image->InitImage(renderer, image, path, x, y, width, height);
	entity->SetDrawable(image);

	m_Entities.push_back(entity);
	return image;
}

void EntityManager::Init(Hero* hero)
{
	m_hero = hero;
}

void EntityManager::AddEntities(Entity* entity)
{
	m_Entities.push_back(entity);
}

void EntityManager::AddPlayerProj(Projectile* projectile)
{
	m_PlayerProj.push_back(projectile);
}

void EntityManager::AddEnemyProj(Projectile* projectile)
{
	m_EnemyProj.push_back(projectile);
}

void EntityManager::AddBossProj(Projectile* projectile)
{
	m_BossProj.push_back(projectile);
}

void EntityManager::AddMiniBossProj(Projectile* projectile)
{
	m_MiniBossProj.push_back(projectile);
}

void EntityManager::CheckCollision()
{
	EnemyManager enM = EnemyManager::Get();

	for (int i = 0; i < enM.GetEnemyList().size(); i++)
	{
		for (int j = 0; j < m_PlayerProj.size(); j++)
		{
			if (m_PlayerProj[j]->IsDestroyed())
				continue;
			//Check la collision entre un ennemie et un projectile
			if (enM.GetEnemyList()[i]->IsColliding(m_PlayerProj[j]))
			{
				m_PlayerProj[j]->Destroy();
				enM.GetEnemyList()[i]->TakeDamage(1);
			}
		}

		//entre perso et ennemie
		if (m_hero->IsColliding(enM.GetEnemyList()[i]))
		{
			enM.GetEnemyList()[i]->Destroy();
			m_hero->TakeDamage(1);
		}

		//ennemie hors de l'ecran
		if (enM.GetEnemyList()[i]->GetPosition(1.f, 0.f).x < 0)
			enM.GetEnemyList()[i]->Destroy();
	}

	for (int i = 0; i < m_EnemyProj.size(); i++)	// projectile ennemie et le perso
	{
		if (m_EnemyProj[i]->IsColliding(m_hero))
		{
			m_EnemyProj[i]->Destroy();
			m_hero->TakeDamage(1);
		}
	}

	for (int i = 0; i < m_PlayerProj.size(); i++)	// proj joueur hors de l'�cran
	{
		if (m_PlayerProj[i]->GetPosition(1.f, 0.f).x > WIDTH)
			m_PlayerProj[i]->Destroy();
	}

	for (int i = 0; i < m_EnemyProj.size(); i++)	// proj ennemie hors de l'�cran
	{
		if (m_EnemyProj[i]->GetPosition(1.f, 0.f).x > WIDTH)
			m_EnemyProj[i]->Destroy();
	}

	for (int i = 0; i < m_BossProj.size(); i++)		// proj boss hors de l'�cran
	{
		if (m_BossProj[i]->GetPosition(1.f, 0.f).x > WIDTH)
			m_BossProj[i]->Destroy();
	}

}

bool EntityManager::Update(SDL_Renderer* renderer, float deltaTime)
{
	EntityManager& em = EntityManager::Get();
	GameManager& gm = GameManager::Get();
	EnemyManager& enM = EnemyManager::Get();
	std::vector<Enemy*> enemyList = enM.GetEnemyList();


	for (auto it : enM.GetEnemyList())
	{
		it->Update(renderer, deltaTime);
	}

	em.GetHero()->Update(renderer, deltaTime);

	CheckCollision();

	if (m_hero->IsDestroyed())
	{
		return false;
	}

	for (int i = 0; i < m_PlayerProj.size();)
	{
		if (m_PlayerProj[i]->IsDestroyed())
		{
			delete m_PlayerProj[i];
			m_PlayerProj.erase(m_PlayerProj.begin() + i);
			m_hero->ChangeShootAmount(-1);
			continue;
		}
		i++;
	}

	for (int i = 0; i < m_EnemyProj.size();)
	{
		if (m_EnemyProj[i]->IsDestroyed())
		{
			delete m_EnemyProj[i];
			m_EnemyProj.erase(m_EnemyProj.begin() + i);
			continue;
		}
		i++;
	}

	for (int i = 0; i < m_BossProj.size();)
	{
		if (m_BossProj[i]->IsDestroyed())
		{
			delete m_BossProj[i];
			m_BossProj.erase(m_BossProj.begin() + i);
			continue;
		}
		i++;
	}

	for (int i = 0; i < enM.GetEnemyList().size();)
	{
		if (enM.GetEnemyList()[i]->IsDestroyed())
		{
			delete enM.GetEnemyList()[i];
			enM.DeleteEnemy(i);
			this->ChangeEnemyNbr(-1);
			continue;
		}
		i++;
	}
	return true;
}
