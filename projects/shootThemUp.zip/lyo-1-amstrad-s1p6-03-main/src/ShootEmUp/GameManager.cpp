#include "GameManager.h"
#include "InputManager.h"
#include "LevelManager.h"
#include "EnemyManager.h"
#include "ProjectileManager.h"
#include "ParalaxManager.h"
#include "Hero.h"
#include "Projectile.h"
#include "Rectangle.h"
#include "Circle.h"
#include "Image.h"

GameManager& GameManager::Get()
{
	static GameManager Instance;

	return Instance;
}

void GameManager::StartGame(SDL_Renderer* render)
{
	srand(time(NULL));

	renderer = render;

	float deltaTime = 0;

	InputManager& im = InputManager::Get();
	LevelManager& lm = LevelManager::Get();
	EntityManager& em = EntityManager::Get();
	EnemyManager& enM = EnemyManager::Get();
	ProjectileManager& prm = ProjectileManager::Get();
	ParalaxManager& pm = ParalaxManager::Get();
	Image& i = Image::Get();

	Color color(104, 8, 50, 255);
	SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

	//Create
	pm.ParaList();
	Entity* paralaxEntity1 = new Entity;
	Image* paralax1 = pm.CreateParalax(renderer, paralaxEntity1, 0, 0, WIDTH, HEIGHT);

	Entity* paralaxEntity2 = new Entity;
	Image* paralax2 = pm.CreateParalax(renderer, paralaxEntity2, WIDTH, 0, WIDTH, HEIGHT);

	Entity* backgroundEntity1 = new Entity;
	Image* backgroundImage1 = em.CreateEntity(renderer, backgroundEntity1, 0, 0, 0, 0, WIDTH, HEIGHT, "../../res/Sprites/Background/PurpleSky.png");

	Entity* backgroundEntity2 = new Entity;
	Image* backgroundImage2 = em.CreateEntity(renderer, backgroundEntity2, WIDTH, 0, 0, 0, WIDTH, HEIGHT, "../../res/Sprites/Background/PurpleSky.png");

	Entity* witch = new Entity;
	Image* heroPicture = em.CreateEntity(renderer, witch, XLIMIT / 2, HEIGHT / 2, 0.5f, 0.5f, 64 * 2, 64 * 2, "../../res/Sprites/Eleonore/Idle/Idle1.png");

	Hero* heartHero = new Hero();

	heartHero->Initialise(XLIMIT / 2, HEIGHT / 2, 1, 10, 500);
	Image* heartPicture = em.CreateEntity(renderer, heartHero, XLIMIT / 2, HEIGHT / 2, 0.1f, 0.1f, 19, 19, "../../res/Sprites/Eleonore/heart.png");
	em.Init(heartHero);

	while (true)
	{
		Uint64 firstFrame = SDL_GetTicks64();

		//EVENT
		im.HandleInput();

		if (lm.HandleLevel(renderer) == false)
		{
			std::cout << "Bravo, vous avez gagne" << std::endl;
			return;
		}


		//UPDATE
		if (im.UpdateMove(renderer, witch, deltaTime) == false)
			return;


		prm.Update(renderer, deltaTime);

		if (em.Update(renderer, deltaTime) == false)
		{
			std::cout << "Vous etes mort, vous avez perdu." << std::endl;
			return;
		}

		//BACKGROUND MOVE
		Background(deltaTime);

		//PARALAX MOVE
		Paralax(deltaTime);

		//DRAW
		Drawing();

		//FPS
		deltaTime = FPS(firstFrame);

		//PLAYER ANIMATION
		heartHero->Animation(renderer, heroPicture, deltaTime);
	}
}

void GameManager::Drawing()
{
	EntityManager& em = EntityManager::Get();
	EnemyManager enM = EnemyManager::Get();

	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
	/*
	ParalaxManager& pm = ParalaxManager::Get();
	std::vector<Image*>& para = pm.GetParalax();
	int test = para[0]->GetX();

	for (int currentPara = 0; currentPara < 2; currentPara++)
		para[currentPara]->Draw(renderer, para[currentPara]->GetX(), para[currentPara]->GetY(), para[currentPara]->GetWidth(), para[currentPara]->GetHeight());
	*/
	std::vector<Entity*>& entity = em.GetEntities();
	int maxEntitiy = entity.size();

	for (int currentEntity = 0; currentEntity < maxEntitiy; currentEntity++)
		entity[currentEntity]->Draw(renderer);

	for (auto it : em.GetPlayerProj())
		it->Draw(renderer);

	for (auto it : em.GetEnemyProj())
		it->Draw(renderer);

	for (auto it : em.GetBossProj())
		it->Draw(renderer);

	for (auto it : em.GetMiniBossProj())
		it->Draw(renderer);

	for (auto it : enM.GetEnemyList())
		it->Draw(renderer);

	SDL_RenderPresent(renderer);
}

float GameManager::FPS(int start)
{
	Uint64 end = SDL_GetTicks64();

	float deltaTime = (end - start) / 1000.f;
	float diff = TARGET_DELTA_TIME - deltaTime;

	if (diff > 0)
	{
		SDL_Delay(diff * 1000);
		deltaTime = TARGET_DELTA_TIME;
	}

	return deltaTime;
}

void GameManager::Background(float deltaTime)
{
	EntityManager& em = EntityManager::Get();

	std::vector<Entity*> entity = em.GetEntities();

	//Move Background
	entity[2]->Move(-100.f * deltaTime, 0.f); //entity[2] == backgroundEntity1
	entity[3]->Move(-100.f * deltaTime, 0.f); //entity[3] == backgroundEntity2

	//Reset Background Position
	if (entity[2]->GetX() <= -WIDTH)
		entity[2]->Initialise(WIDTH, 0, WIDTH, HEIGHT);

	if (entity[3]->GetX() <= -WIDTH)
		entity[3]->Initialise(WIDTH, 0, WIDTH, HEIGHT);
}

void GameManager::Paralax(float deltaTime)
{
	EntityManager& em = EntityManager::Get();

	std::vector<Entity*> entity = em.GetEntities();

	entity[0]->Move(-100.f * deltaTime, 0.f);
	entity[1]->Move(-100.f * deltaTime, 0.f);

	if (entity[0]->GetX() <= -WIDTH)
		entity[0]->Initialise(WIDTH, 0, WIDTH, HEIGHT);

	if (entity[1]->GetX() <= -WIDTH)
		entity[1]->Initialise(WIDTH, 0, WIDTH, HEIGHT);

}

void GameManager::End()
{
	EntityManager& em = EntityManager::Get();
	std::vector<Entity*>& entity = em.GetEntities();
	int maxEntitiy = entity.size();

	EnemyManager enM = EnemyManager::Get();
	std::vector<Enemy*>& enemy = enM.GetEnemyList();
	int maxEnemy = enemy.size();

	for (int i = 6; i < maxEntitiy; i++)
		entity[i]->Destroy();

	for (int i = 0; i < maxEnemy; i++)
		enemy[i]->Destroy();

	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);

	for (int currentEntity = 0; currentEntity < 6; currentEntity++)
		entity[currentEntity]->Draw(renderer);

	SDL_RenderPresent(renderer);
}
