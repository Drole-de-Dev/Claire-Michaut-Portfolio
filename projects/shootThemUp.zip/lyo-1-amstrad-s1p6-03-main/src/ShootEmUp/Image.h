#pragma once
#include <SDL_image.h>
#include <vector>

#include "Drawable.h"

class Image : public Drawable
{
private:
	std::vector<Image*> m_Images;
	SDL_Texture* texture = nullptr;
	const char* currentPath = nullptr;

	int m_x = 0;
	int m_y = 0;
	int m_width = 0;
	int m_height = 0;

public:

	static Image& Get();

	std::vector<Image*> GetImages() {
		return m_Images;
	}

	float GetWidth() {
		return m_width;
	}

	float GetHeight() {
		return m_height;
	}

	float GetX() {
		return m_x;
	}

	float GetY() {
		return m_y;
	}

	void InitImage(SDL_Renderer* renderer, Image* image, const char* path, float x, float y, int width, int height);

	void Draw(SDL_Renderer* renderer, int x, int y, int width, int height) override;

	void Resize(SDL_Rect dst, int width, int height);

	void Move(float x, float y);
};

