#pragma once
#include "Entity.h"

#include <vector>

class Image;
class Hero;
class Enemy;
class Projectile;

class EntityManager : public Entity
{
private:
	std::vector<Entity*> m_Entities;
	std::vector<Projectile*> m_PlayerProj;
	std::vector<Projectile*> m_EnemyProj;
	std::vector<Projectile*> m_BossProj;
	std::vector<Projectile*> m_MiniBossProj;

	int m_nbrEnemy = 0;
	Hero* m_hero = nullptr;

	EntityManager() {};

public:
	static EntityManager& Get();

	std::vector<Entity*>& GetEntities() { return m_Entities; }
	std::vector<Projectile*>& GetPlayerProj() { return m_PlayerProj; }
	std::vector<Projectile*>& GetEnemyProj() { return m_EnemyProj; }
	std::vector<Projectile*>& GetBossProj() { return m_BossProj; }
	std::vector<Projectile*>& GetMiniBossProj() { return m_MiniBossProj; }

	Hero* GetHero() { return m_hero; }
	int GetEnemyNbr() { return m_nbrEnemy; }

	void ChangeEnemyNbr(int change) { m_nbrEnemy += change; }

	Image* CreateEntity(SDL_Renderer* renderer, Entity* entity, int x, int y, float ax, float ay, int width, int height, const char* path);

	void Init(Hero* hero);

	void AddEntities(Entity* entity);
	void AddPlayerProj(Projectile* projectile);
	void AddEnemyProj(Projectile* projectile);
	void AddBossProj(Projectile* projectile);
	void AddMiniBossProj(Projectile* projectile);

	void AddEnemy(Enemy* enemy);

	void CheckCollision();

	bool Update(SDL_Renderer* renderer, float deltaTime);
};
