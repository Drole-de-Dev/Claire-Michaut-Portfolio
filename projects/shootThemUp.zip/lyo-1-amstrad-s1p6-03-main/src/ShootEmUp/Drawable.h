#pragma once

struct SDL_Renderer;
struct Color;

class Drawable
{

public:
	virtual void Draw(SDL_Renderer* renderer, int x, int y, int width, int height) = 0;
};