#pragma once 
#include <SDL.h>
#include <vector>
#include <string>

class Enemy;

class LevelManager
{
private:
	std::vector<std::string> level;

public: 
	static LevelManager& Get();

	std::vector<std::string> GetString() { return level; }

	bool HandleLevel(SDL_Renderer* renderer);

	void LoadLevel(const char* path);

};