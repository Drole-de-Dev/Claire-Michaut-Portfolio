#pragma once
#include <SDL.h>
#include <iostream>

class Window
{
public:
	Window() {};

	SDL_Window* CreateWindow(const char* name, int x, int y, int width, int height);

	void DestroyWindow(SDL_Window* window, SDL_Renderer* renderer);
};

