#include "ProjectileManager.h"
#include "EntityManager.h"
#include "Projectile.h"

ProjectileManager& ProjectileManager::Get()
{
	static ProjectileManager Instance;

	return Instance;
}

void ProjectileManager::Update(SDL_Renderer* renderer, float deltaTime)
{
	EntityManager& em = EntityManager::Get();
	int attackNbr = 0;

	if (em.GetPlayerProj().size() > 0)
	{
		for (auto it : em.GetPlayerProj())
			it->Move(it->GetSpeed() * deltaTime * it->GetDirection().x, it->GetSpeed() * deltaTime * it->GetDirection().y);
	}

	if (em.GetEnemyProj().size() > 0)
	{
		for (auto it : em.GetEnemyProj())
			it->Move(it->GetSpeed() * deltaTime * it->GetDirection().x, it->GetSpeed() * deltaTime * it->GetDirection().y);
	}

	if (em.GetBossProj().size() > 0)
	{
		
		for (Projectile* proj : em.GetBossProj())
		{
			if (proj->GetPosition(0.5f, 0.f).x <= proj->GetExplosionZone())
			{
				em.GetBossProj().erase(em.GetBossProj().begin() + attackNbr);
				proj->Explosion(renderer, deltaTime);
			}

			proj->Move(proj->GetSpeed() * deltaTime * proj->GetDirection().x, proj->GetSpeed() * deltaTime * proj->GetDirection().y);
			attackNbr++;
		}

		std::vector<Projectile*>& bossProj = em.GetBossProj();

		for (int i = 0; i < bossProj.size();)
		{
			bossProj[i]->Move(bossProj[i]->GetSpeed() * deltaTime * bossProj[i]->GetDirection().x, bossProj[i]->GetSpeed() * deltaTime * bossProj[i]->GetDirection().y);

			if (bossProj[i]->GetPosition(0.5f, 0.f).x <= bossProj[i]->GetExplosionZone())
			{
				bossProj[i]->Destroy();
				bossProj[i]->Explosion(renderer, deltaTime);
			}

			if (bossProj[i]->IsDestroyed())
			{
				delete bossProj[i];
				bossProj.erase(bossProj.begin() + i);
				continue;
			}
			i++;
		}
	}
}
