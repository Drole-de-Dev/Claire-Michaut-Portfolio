#pragma once

struct SDL_Renderer;
class EntityManager;
class ParalaxManager;
class Image;
class Circle;

class GameManager
{
private:
	SDL_Renderer* renderer;

public:
	static GameManager& Get();

	void StartGame(SDL_Renderer* renderer);

	void Drawing();

	float FPS(int start);

	void Background(float deltaTime);

	void Paralax(float deltaTime);

	void End();
};
