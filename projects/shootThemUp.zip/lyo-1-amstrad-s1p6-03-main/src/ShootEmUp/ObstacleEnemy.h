#pragma once

#include "Enemy.h"

class ObstacleEnemy : public Enemy
{
private:

public:
	ObstacleEnemy();

	void Update(SDL_Renderer* renderer, float deltaTime) override;
};
