#include "Window.h"
#include "GameManager.h"
#include "Utility.h"

int main(int argc, char** argv)
{
	Window win;
	SDL_Window* WindowShoot;

	WindowShoot = win.CreateWindow("Shoot'em up", 0, 0, WIDTH, HEIGHT);
	SDL_Renderer* renderer = SDL_CreateRenderer(WindowShoot, -1, SDL_RENDERER_ACCELERATED);

	GameManager game;
	game.StartGame(renderer);

	std::cout << "Ending game" << std::endl;

	game.End();

	SDL_Delay(8000);

	win.DestroyWindow(WindowShoot, renderer);
	return 0;
}
