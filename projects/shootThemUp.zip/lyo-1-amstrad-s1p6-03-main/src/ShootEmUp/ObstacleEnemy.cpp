#include "ObstacleEnemy.h"

ObstacleEnemy::ObstacleEnemy()
{
	m_attack = 1;
	m_health = 3;
	m_speed = 225;
}

void ObstacleEnemy::Update(SDL_Renderer* renderer, float deltaTime)
{
	if (IsAlive() == false)
		Destroy();

	Move(-m_speed * deltaTime, 0.f);
}
