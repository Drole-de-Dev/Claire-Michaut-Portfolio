#pragma once
#include <SDL.h>

class ProjectileManager
{
public:
	static ProjectileManager& Get();

	void Update(SDL_Renderer* renderer, float deltaTime);
};