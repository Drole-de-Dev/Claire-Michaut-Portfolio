#pragma once
#include "Image.h"
#include "EntityManager.h"

#include <time.h>

class ParalaxManager : public Image
{
private:
	std::vector<Image*> m_Paralax;
	std::vector<const char*> m_paths;
	const char* currentPath;

public:

	static ParalaxManager& Get();

	Image* CreateParalax(SDL_Renderer* renderer, Entity* entity, int x, int y, int width, int height);

	const char* GetCurrentPath()
	{
		return currentPath;
	}

	std::vector<Image*>& GetParalax() {
		return m_Paralax;
	}

	void ParaList();

	const char* NewPath();
};

