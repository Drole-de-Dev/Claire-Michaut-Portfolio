#pragma once

#include "Enemy.h"

class VerticalEnemy : public Enemy
{
private:

public:
	VerticalEnemy();

	void Attack(SDL_Renderer* renderer, float deltaTime) override;

	void Update(SDL_Renderer* renderer, float deltaTime) override;
};
