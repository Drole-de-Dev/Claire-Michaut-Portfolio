#include "Window.h"

SDL_Window* Window::CreateWindow(const char* name, int x, int y, int width, int height)
{

	if (SDL_Init(SDL_INIT_VIDEO) != 0)
	{
		std::cout << "SDL_Init Error: " << SDL_GetError() << std::endl;
		return NULL;
	}

	SDL_Window* window = SDL_CreateWindow(name, x, y, width, height, SDL_WINDOW_SHOWN);

	if (!window)
	{
		std::cout << "SDL_CreateWindow Error: " << SDL_GetError() << std::endl;
		SDL_Quit();
		return NULL;
	}

	return window;
}

void Window::DestroyWindow(SDL_Window* window, SDL_Renderer* renderer)
{
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
}

