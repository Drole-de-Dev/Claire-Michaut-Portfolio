#include "Hero.h"
#include "Image.h"

#include <SDL.h>
#include <iostream>

void Hero::Initialise(int x, int y, int attack, int health, int speed)
{
	m_x = x;
	m_y = y; 
	m_width = 64;
	m_height = 64;
	InitPath();

	m_attack = attack;
	m_health = health;
	m_speed = speed;

	m_canShoot = 0;
	m_shootCouldown = 200;
}
 
void Hero::ChangeShootAmount(int change)
{
	shootCount += change;
}

void Hero::HealthBar()
{

}

void Hero::InitPath()
{
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle1.png");
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle2.png");
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle3.png");
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle4.png");
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle5.png");
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle6.png");
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle7.png");
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle8.png");
	m_paths.push_back("../../res/Sprites/Eleonore/Idle/Idle9.png");
}

void Hero::Animation(SDL_Renderer* renderer, Image* heroPicture, float deltaTime)
{
	frameCount += deltaTime;

	if (frameCount * 200 > 10)
	{
		frameCount = 0;

		currentPath = m_paths[sprite];
		sprite++;

		if (sprite == 9)
			sprite = 0;


		heroPicture->InitImage(renderer, heroPicture, GetCurrentPath(), GetX(), GetY(), GetWidth(), GetHeight());
	}
}

void Hero::Update(SDL_Renderer* renderer, float deltaTime)
{
	if (IsAlive() == false)
		Destroy();
}