#pragma once

#include "Drawable.h"

class Rectangle : public Drawable
{
public:

	Rectangle() {}; 

	void Draw(SDL_Renderer* renderer,  int x, int y, int width, int height) override;
};
