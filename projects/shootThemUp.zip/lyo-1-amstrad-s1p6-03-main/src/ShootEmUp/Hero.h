#pragma once
#include "Character.h"
#include <vector>

class Image;

class Hero : public Character
{
private:
	std::vector<const char*> m_paths;
	const char* currentPath = "../../res/Sprites/Eleonore/Idle/Idle1.png";

	float frameCount = 0; 
	int sprite = 0;
	int shootCount = 0;
	int health = 0;

	float m_canShoot = 0;
	int m_shootCouldown = 0;

public:
	Hero() {}

	void Initialise(int x, int y, int attack, int health, int speed);

	const char* GetCurrentPath() const { return currentPath; }
	int GetSpeed() { return m_speed;  }
	int GetShootAmount() { return shootCount; }

	void ChangeShootAmount(int change);

	void HealthBar();

	void InitPath();
	void Animation(SDL_Renderer* renderer, Image* heroPicture, float deltaTime);

	void Update(SDL_Renderer* renderer, float deltaTime);
};
