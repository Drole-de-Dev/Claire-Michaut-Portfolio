#pragma once
#include <SDL.h>

class Menu
{
public:
};

