#include "EntityManager.h"
#include "Entity.h"
#include "Projectile.h"
#include "VerticalEnemy.h"
#include "Image.h"



VerticalEnemy::VerticalEnemy()
{
	m_attack = 1;
	m_health = 2;
	m_speed = 225;
}

void VerticalEnemy::Attack(SDL_Renderer* renderer, float deltaTime)
{
	EntityManager& em = EntityManager::Get();

	if (atkTimer < 0.5f)
	{
		atkTimer += deltaTime;
		return;
	}

	atkTimer = 0;

	Projectile* attack = new Projectile(40, 32, 175, -1, 0);
	Image* image = new Image();
	attack->SetDrawable(image);
	attack->SetPosition(GetPosition(0.f, 0.5f).x - 10, GetPosition(0.5f, 0.5f).y, 0.f, 0.5f);
	image->InitImage(renderer, image, "../../res/Sprites/Enemies/FireProjectile.png", attack->GetX(), attack->GetY(), attack->GetWidth(), attack->GetHeight());
	em.AddEnemyProj(attack);
}

void VerticalEnemy::Update(SDL_Renderer* renderer, float deltaTime)
{
	if (IsAlive() == false)
		Destroy();

	Attack(renderer, deltaTime);

	Move(0.f, m_speed * deltaTime);

	if (GetPosition(0.f, 1.f).y >= HEIGHT - 5)
		m_speed = -m_speed;
	if (GetPosition(0.f, 0.f).y <= 5)
		m_speed = -m_speed;
}
