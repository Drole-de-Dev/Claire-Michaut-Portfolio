#pragma once
#include "SDL.h"
#include <iostream>
#include <map>

class Entity;

class InputManager
{
	struct State
	{
		bool isDown;
		bool isHeld;
		bool isUp;
	};

	State m_states[SDL_NUM_SCANCODES];

public:
	static InputManager& Get();

	bool UpdateMove(SDL_Renderer* renderer, Entity* witch, float deltaTime);

	void HandleInput();

	bool IsDown(SDL_KeyCode key);

	bool IsHeld(SDL_KeyCode key);

	bool IsUp(SDL_KeyCode key);
};
