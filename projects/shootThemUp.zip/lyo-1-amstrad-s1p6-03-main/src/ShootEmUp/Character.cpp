#include "Character.h"

void Character::TakeDamage(int dmg)
{
	m_health -= dmg;
}

void Character::Update(SDL_Renderer* renderer, float deltaTime)
{
}

bool Character::IsAlive()
{
	if (m_health <= 0)
		return false;

	return true;
}