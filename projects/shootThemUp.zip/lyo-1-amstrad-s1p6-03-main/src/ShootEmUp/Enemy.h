#pragma once
#include "Character.h"


class Enemy : public Character
{
protected:
	int enemyOnScreen = 0;
	float atkTimer = 0;

public:
	Enemy() {};

	virtual void Attack(SDL_Renderer* renderer, float deltaTime) {}

	virtual void Update(SDL_Renderer* renderer, float deltaTime) {}
};