#include "Entity.h"
#include "Drawable.h"

#include <iostream>
#include <SDL.h>
#include <SDL_image.h>

void Entity::Initialise(int x, int y, int width, int height)
{
	m_x = x;
	m_y = y;
	m_width = width;
	m_height = height;

	m_color = { 108, 4, 134, 255 };
}

void Entity::SetDrawable(Drawable* drawable)
{
		if (m_drawable != nullptr)
			delete m_drawable;

		m_drawable = drawable;
}

Vector2 Entity::GetPosition(float anchorX, float anchorY) const
{
	Vector2 pos;

	pos.x = m_x + m_width * anchorX;
	pos.y = m_y + m_height * anchorY;

	return pos;
}

void Entity::SetPosition(float x, float y, float anchorX, float anchorY)
{
	m_x = x - m_width * anchorX;
	m_y = y - m_height * anchorY;
}

void Entity::SetPosition(const Vector2& position, float anchorX, float anchorY)
{
	SetPosition(position.x, position.y, anchorX, anchorY);
}

void Entity::Move(float x, float y)
{
	m_x += x;
	m_y += y;
}

void Entity::Resize(int width, int height)
{
	m_width = width;
	m_height = height;
}

bool Entity::IsColliding(const Entity* target)
{
	Vector2 pos1 = GetPosition(0.5f, 0.5f);
	Vector2 pos2 = target->GetPosition(0.5f, 0.5f);

	int centerDistance = std::sqrt(std::pow((pos1.x - pos2.x), 2) + std::pow((pos1.y - pos2.y), 2));

	int totalRadius = (m_width / 2) + (target->m_width / 2);

	return centerDistance <= totalRadius;
}

bool Entity::IsDestroyed()
{
	return m_destroy;
}

void Entity::Destroy()
{
	m_destroy = true;
}

void Entity::Draw(SDL_Renderer* renderer)
{
	m_drawable->Draw(renderer, m_x, m_y, m_width, m_height);
}