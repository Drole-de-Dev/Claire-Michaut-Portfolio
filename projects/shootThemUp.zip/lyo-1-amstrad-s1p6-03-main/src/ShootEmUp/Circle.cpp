#include "Circle.h"
#include "Utility.h"

#include <iostream>
#include <SDL.h>

Circle::Circle(int precision)
{
	m_precision = precision;
}

void Circle::Draw(SDL_Renderer* renderer, int x, int y, int width, int height)
{
	float perimeter = 2 * M_PI;
	float step = perimeter / m_precision;

	float radius = width / 2;

	int centerX = x + width / 2;
	int centerY = y + height / 2;

	int lastX = radius * cos(0) + centerX;
	int lastY = radius * sin(0) + centerY;

	for (int i = 1; i <= m_precision; i++)
	{
		int currentX = radius * cos(step * i) + centerX;
		int currentY = radius * sin(step * i) + centerY;

		SDL_RenderDrawLine(renderer, lastX, lastY, currentX, currentY);

		lastX = currentX;
		lastY = currentY;
	}
}

/*bool Circle::IsColliding(const Circle* target)
{
	Vector2 pos1 = GetPosition(0.5f, 0.5f);
	Vector2 pos2 = target->GetPosition(0.5f, 0.5f);

	int centerDistance = std::sqrt(std::pow((pos1.x - pos2.x), 2) + std::pow((pos1.y - pos2.y), 2));

	int totalRadius = GetRadius() + target->GetRadius();

	return centerDistance <= totalRadius;
}
*/