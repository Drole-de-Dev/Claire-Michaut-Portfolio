#include "Image.h"	
#include "Hero.h"
#include "AssetManager.h"

Image& Image::Get()
{
	static Image Instance;

	return Instance;
}

void Image::InitImage(SDL_Renderer* renderer, Image* image, const char* path, float x, float y, int width, int height)
{
	texture = AssetManager::Get()->LoadTexture(renderer, path);
	currentPath = path;

	m_x = x;
	m_y = y;
	m_width = width;
	m_height = height;

	m_Images.push_back(image);
}

void Image::Draw(SDL_Renderer* renderer, int x, int y, int width, int height)
{
	SDL_Rect dst = { x, y, width, height };
	SDL_QueryTexture(texture, NULL, NULL, &width, &height);

	Resize(dst, width, height);

	SDL_RenderCopy(renderer, texture, NULL, &dst);
}

void Image::Resize(SDL_Rect dst, int width, int height)
{
	float ratio = (float)dst.h / (float)dst.w;

	if (width > height)
	{
		dst.w = height / ratio;
		dst.h = height;
	}
	else
	{
		dst.w = width;
		dst.h = ratio * width;
	}
}

void Image::Move(float x, float y)
{
	m_x += x;
	m_y += y;
}