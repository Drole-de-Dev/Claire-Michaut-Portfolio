#pragma once

#include "Utility.h"

struct SDL_Renderer;

class Drawable;

class Entity
{
protected:
	float m_x = 0;
	float m_y = 0;
	Vector2f m_direction;
	int m_width = 0;
	int m_height = 0;
	int m_speed = 500;

	bool m_destroy = false;

	Color m_color = { 108, 4, 134, 255 };

	Drawable* m_drawable = nullptr;

public:
	//Entity() {};

	float GetWidth() {return m_width;}

	float GetHeight() { return m_height; }

	float GetX() {return m_x;}

	float GetY() {return m_y;}

	int GetSpeed() { return m_speed; }

	Vector2f GetDirection() { return m_direction; }

	virtual void Initialise(int x, int y, int width, int height);

	void SetDrawable(Drawable* drawable);

	virtual Vector2 GetPosition(float anchorX, float anchorY) const;

	virtual void SetPosition(float x, float y, float anchorX, float anchorY);

	virtual void SetPosition(const Vector2& position, float anchorX, float anchorY);

	virtual void Move(float x, float y);

	virtual void Resize(int width, int height);

	bool IsColliding(const Entity* target);

	void TakeDamage(int dmg);

	bool IsAlive();

	bool IsDestroyed();
	void Destroy();

	virtual void Draw(SDL_Renderer* renderer);

	void SetColor(const Color& color) { m_color = color; }
};
