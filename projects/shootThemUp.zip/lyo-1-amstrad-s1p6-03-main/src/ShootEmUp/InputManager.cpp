#include "GameManager.h"
#include "InputManager.h"
#include "Utility.h"
#include "Image.h"
#include "Hero.h"
#include "Circle.h"
#include "EntityManager.h"
#include "Projectile.h"
#include <iostream>

InputManager& InputManager::Get()
{
	static InputManager Instance;

	return Instance;
}

bool InputManager::UpdateMove(SDL_Renderer* renderer, Entity* witch, float deltaTime)
{
	GameManager& gm = GameManager::Get();
	EntityManager& em = EntityManager::Get();

	if (IsDown(SDLK_ESCAPE))
		return false;

	if (IsHeld(SDLK_q) || IsHeld(SDLK_LEFT))
	{
		if (em.GetHero()->GetPosition(0.f, 0.5f).x > 0)
		{
			em.GetHero()->Move(-em.GetHero()->GetSpeed() * deltaTime, 0.f);
			witch->SetPosition(em.GetHero()->GetX(), em.GetHero()->GetY(), 0.5f, 0.5f);
		}
	}

	if (IsHeld(SDLK_d) || IsHeld(SDLK_RIGHT))
	{
		if (em.GetHero()->GetPosition(1.f, 0.5f).x < XLIMIT)
		{
			em.GetHero()->Move(em.GetHero()->GetSpeed() * deltaTime, 0.f);
			witch->SetPosition(em.GetHero()->GetX(), em.GetHero()->GetY(), 0.5f, 0.5f);
		}
	}

	if (IsHeld(SDLK_z) || IsHeld(SDLK_UP))
	{
		if (em.GetHero()->GetPosition(0.5f, 0.f).y > 0)
		{
			em.GetHero()->Move(0.f, -em.GetHero()->GetSpeed() * deltaTime);
			witch->SetPosition(em.GetHero()->GetX(), em.GetHero()->GetY(), 0.5f, 0.5f);
		}
	}

	if (IsHeld(SDLK_s) || IsHeld(SDLK_DOWN))
	{
		if (em.GetHero()->GetPosition(0.5f, 1.f).y < HEIGHT)
		{
			em.GetHero()->Move(0.f, em.GetHero()->GetSpeed() * deltaTime);
			witch->SetPosition(em.GetHero()->GetX(), em.GetHero()->GetY(), 0.5f, 0.5f);
		}
	}

	if (IsDown(SDLK_SPACE))
	{
		if (em.GetHero()->GetShootAmount() < 10)
		{
			Projectile* fireball = new Projectile(40, 30, 700, 1, 0);
			Image* image = new Image();
			fireball->SetDrawable(image);
			fireball->SetPosition(em.GetHero()->GetPosition(1.f, 0.5f).x + 10, em.GetHero()->GetPosition(0.5f, 0.5f).y, 0.f, 0.5f);
			image->InitImage(renderer, image, "../../res/Sprites/Eleonore/FireProjectile.png", fireball->GetX(), fireball->GetY(), fireball->GetWidth(), fireball->GetHeight());
			em.AddPlayerProj(fireball);
			em.GetHero()->ChangeShootAmount(1);
		}
	}
	return true;
}

void InputManager::HandleInput()
{
	for (int i = 0; i < SDL_NUM_SCANCODES; i++)
	{
		if (m_states[i].isDown)
			m_states[i].isHeld = true;

		if (m_states[i].isUp)
			m_states[i].isHeld = false;

		m_states[i].isDown = false;
		m_states[i].isUp = false;
	}

	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_KEYDOWN:
		{
			if (event.key.repeat)
				break;

			m_states[event.key.keysym.scancode].isDown = true;
			break;
		}
		case SDL_KEYUP:
		{
			m_states[event.key.keysym.scancode].isUp = true;
			break;
		}
		}
	}
}

bool InputManager::IsDown(SDL_KeyCode key)
{
	SDL_Scancode scancode = SDL_GetScancodeFromKey(key);

	return m_states[scancode].isDown;
}

bool InputManager::IsHeld(SDL_KeyCode key)
{
	SDL_Scancode scancode = SDL_GetScancodeFromKey(key);

	return m_states[scancode].isHeld;
}

bool InputManager::IsUp(SDL_KeyCode key)
{
	SDL_Scancode scancode = SDL_GetScancodeFromKey(key);

	return m_states[scancode].isUp;
}
