#pragma once

#include "Enemy.h"
#include <vector>

class EnemyManager : public Enemy
{
protected:
	std::vector<Enemy*> m_EnemyOnScreen;
	int currentWave = 0;

public:
	static EnemyManager& Get();
	
	int GetWave() { return currentWave; }

	void SpawnWave(SDL_Renderer* renderer);

	void NextWave();

	void AddEnemy(Enemy* enemy);
	void DeleteEnemy(int i);
	std::vector<Enemy*>& GetEnemyList() { return m_EnemyOnScreen; }
};