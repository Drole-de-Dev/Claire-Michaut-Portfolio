#include "EntityManager.h"
#include "Boss.h"
#include "Projectile.h"
#include "Image.h"

Boss::Boss()
{
	m_attack = 2;
	m_health = 20; 
	m_speed = 150;
}

void Boss::Attack(SDL_Renderer* renderer, float deltaTime)
{
	EntityManager& em = EntityManager::Get();

	if (atkTimer < 1.f)
	{
		atkTimer += deltaTime;
		return;
	}
	atkTimer = 0;

	Image* image = new Image();
	Projectile* attack = new Projectile(40, 30, 175, -1, 0);
	
	attack->SetPosition(GetPosition(0.f, 0.5f).x - 10, GetPosition(0.5f, 0.5f).y, 0.f, 0.5f);
	image->InitImage(renderer, image, "../../res/Sprites/Boss/CristalProjectile.png", attack->GetX(), attack->GetY(), attack->GetWidth(), attack->GetHeight());
	attack->SetDrawable(image);
	attack->SetExplosionZone();
	em.AddBossProj(attack);
}

void Boss::Update(SDL_Renderer* renderer, float deltaTime)
{
	if (IsAlive() == false)
		Destroy();

	Attack(renderer, deltaTime);

	Move(0.f, m_speed * deltaTime);

	if (GetPosition(0.f, 1.f).y >= HEIGHT - 250)
		m_speed = -m_speed;
	if (GetPosition(0.f, 0.f).y <= 250)
		m_speed = -m_speed;
}
