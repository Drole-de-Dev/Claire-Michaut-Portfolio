#pragma once

struct SDL_Texture;
struct SDL_Renderer;

#include <map>

class AssetManager
{
private:
	static AssetManager* Instance;

	std::map<const char*, SDL_Texture*> m_textures;

	AssetManager() {};

public:
	static AssetManager* Get();

	SDL_Texture* LoadTexture(SDL_Renderer* renderer, const char* path);

	void HeroIdle();

	void Ennemy();

	void Obstacle();

	void Boss();

	void Background();

	void Paralax();

};

