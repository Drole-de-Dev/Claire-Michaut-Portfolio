#pragma once

#include "Enemy.h"

class Boss: public Enemy
{
private:

public:
	Boss();

	void Attack(SDL_Renderer* renderer, float deltaTime) override;

	void Update(SDL_Renderer* renderer, float deltaTime) override;
};