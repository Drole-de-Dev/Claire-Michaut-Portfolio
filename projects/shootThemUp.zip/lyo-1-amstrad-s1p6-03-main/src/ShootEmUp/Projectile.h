#pragma once

#include "Entity.h"

struct SDL_Renderer;

class Projectile : public Entity
{
private:
	int m_speed;
	int m_explosionZone;

public:
	Projectile(int width, int height, int speed, int xDir, int yDir);

	void Explosion(SDL_Renderer* renderer, float deltaTime);

	void SetExplosionZone();

	const int GetSpeed() { return m_speed; }
	int GetExplosionZone() { return m_explosionZone; }
};
